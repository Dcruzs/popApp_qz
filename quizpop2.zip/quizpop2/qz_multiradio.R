ui <- fluidPage(
  
  tags$h2(" Quiz: Population growth App"),
  br(),
  
  prettyRadioButtons("radio", 
               label = "Question 1: What demographic parameter would equal zero in a closed population model?",
               choices = list ("Death" = 1, "Birth" = 2,"Migration" = 3),
               selected = character(0),
               width = "100%"),
  textOutput("value"),


  prettyRadioButtons("radio2", 
             label = "Question 2: Giving that r is a constant that measures the difference between birth and death rates, what situation is the population size growing?",
                      choices = list ("b > d" = 1, "b < d" = 2,"b = d" = 3),
             selected = character(0),
             width = "100%"),
      textOutput("value2"),
  
  prettyRadioButtons("radio3", 
               label = " Question 3: What portion of the population growth model (see equation below) represents the Intrinsic growth rate (r) or the per capita rate of population increase over time?", 
              choices = list ("dN/dt" = 1, "rN" = 2,"dN/Ndt" = 3),
               selected = character(0),
               width = "100%"),
              div(img(src = "pop_change_rate.png", height = 60, width = 100, 
                      ##style="display: block; margin-left: auto; margin-right: auto;")), Good
                    style="display: block; margin-left: auto; margin-right: auto;")),
              #img(src = "pop_change_rate.png", height = 60, width = 100, align = "center"), ## GOOD
  #imageOutput(outputId="www/pop_change_rate.png"),## ERROR
  textOutput("value3"))
  


# Define server logic required to draw a histogram  
server <- function(input, output){
  output$value <- renderPrint({
    if(isTRUE(input$radio == 3)){return('Great Job !')} ## isTRUE() worked and "selected =character(0)" at ui
    if(isTRUE(input$radio == 1)){return('Try it again!')}
    if(isTRUE(input$radio == 2)){return('Try it again!')}
    else{return("Choose your answer")}})
  
  output$value2 <- renderPrint({
    if(isTRUE(input$radio2 == 1)){return('Great Job !')}
    if(isTRUE(input$radio2 == 2)){return('Try it again!')}
    if(isTRUE(input$radio2 == 3)){return('Try it again!')}
    else{return("Choose your answer")}})
  
  output$value3 <- renderPrint({
    if(isTRUE(input$radio3 == 3)){return('Great Job !')}
    if(isTRUE(input$radio3 == 1)){return('Try it again!')} ## added all this "If" to avoid the "try agon message whne thre is not response one opne the App
    if(isTRUE(input$radio3 == 2)){return('Try it again!')}
    else{return("Choose your answer")}})
  
  }

# Create Shiny app ----  
shinyApp(ui = ui, server = server)